package dictionary;

/**
 * <p>
 * Title: DictEntry Class - A class component of the Dictionary system
 * </p>
 *
 * <p>
 * Description: An entity object class that implements a dictionary entry
 * </p>
 *
 * <p>
 * Copyright: Copyright © 2018-05-05
 * </p>
 *
 * @author Lynn Robert Carter, Jaskirat
 * @author Nikhil. p
 * @version 2.00 - Baseline for transition from Swing to JavaFX 2018-05-05
 * @version 2.01 - Installed in PKMT Tool
 * @version 3.00 2019-02-05 added Generic class and converted into API
 * 
 */

public class DictEntry<T> {

	/**********************************************************************************************
	 * 
	 * Class Attributes
	 * 
	 **********************************************************************************************/
	private String name; // A dictionary entry's word
	private T value; // A dictionary entry's definition
	private boolean variable;

	/**********************************************************************************************
	 * 
	 * Constructors
	 * 
	 **********************************************************************************************/

	/**********
	 * This is the default constructor. We do not expect it to be used.
	 */
	public DictEntry() {
		name = "";
		value = getValue();
		variable = false;
	}

	/**********
	 * This is defining constructor. This is the one we expect people to use.
	 */
	public DictEntry(String n, T d) {
		name = n;
		value = d;
	}

	/**********************************************************************************************
	 * 
	 * Standard support methods
	 * 
	 **********************************************************************************************/

	/**********
	 * This is the debugging toString method.
	 */
	public String toString() {
		return name + "\n" + value + "\n" + variable;
	}

	/**********
	 * This is the formatted toString method.
	 */
	public String formattedToString() {
		return name + "\n" + value + "\n--------------------\n" ;
	}

	/**********
	 * These are the getters and setters for the class
	 */
	public String wordToString() {
		return name + "\n";
	}

	public String getName() {
		return name;
	}

	public T getValue() {
		return value;
	}
	
	public boolean getVariable() {
		return variable;
	}

	public void setName(String n) {
		name = n;
	}

	public void setValue(T val) {
		this.value = val;
	}
	
	public void setValue(boolean b) {
		this.variable = b;
	}

}
